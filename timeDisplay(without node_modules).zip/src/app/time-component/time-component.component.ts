import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-component',
  templateUrl: './time-component.component.html',
  styleUrls: ['./time-component.component.css']
})
export class TimeComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
