export class TimeClass {
}
